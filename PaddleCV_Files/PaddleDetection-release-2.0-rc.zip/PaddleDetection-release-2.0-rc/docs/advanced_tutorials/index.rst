进阶使用教程
===========================================

.. toctree::
   :maxdepth: 2

   deploy/index
   config_doc/index
   READER.md
   MODEL_TECHNICAL.md
   TRANSFER_LEARNING_cn.md
   slim/index

.. note:: 文中超链接以GitHub中展示为准，如出现超链接无法访问，请点击网页右上角「Edit on github」查看源文件进行索引，有任何问题欢迎在 `GitHub <https://github.com/PaddlePaddle/PaddleDetection>`_ 上提issue。
