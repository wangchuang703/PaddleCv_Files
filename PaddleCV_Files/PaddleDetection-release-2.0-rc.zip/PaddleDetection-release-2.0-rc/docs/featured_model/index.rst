特色模型
===========================================

.. toctree::
   :maxdepth: 2

   YOLOv3_ENHANCEMENT.md
   MOBILE_SIDE.md
   SERVER_SIDE.md
   ANCHOR_FREE_DETECTION.md
   YOLO_V4.md
   champion_model/index.rst
   FACE_DETECTION.md
   CONTRIB_cn.md

.. note:: 文中超链接以GitHub中展示为准，如出现超链接无法访问，请点击网页右上角「Edit on github」查看源文件进行索引，有任何问题欢迎在 `GitHub <https://github.com/PaddlePaddle/PaddleDetection>`_ 上提issue。
