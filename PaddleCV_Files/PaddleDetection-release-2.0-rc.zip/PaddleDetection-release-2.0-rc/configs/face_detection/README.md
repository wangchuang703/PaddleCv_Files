**文档教程请参考：** [FACE_DETECTION.md](../../docs/featured_model/FACE_DETECTION.md) <br/>
**English document please refer:** [FACE_DETECTION_en.md](../../docs/featured_model/FACE_DETECTION_en.md)
